import React from 'react';
import PropTypes from 'prop-types';
import styles from './Modal.module.css';

const Modal = (props) => {
    const {children, isOpen, onClose} = props;

    console.log("isOpen=" + isOpen);
    console.log("children=" + children);

    let dialog =  (
        <div className={styles.modal}>
            <button className={styles.modalCloseButton} onClick={onClose}>X</button>
            <div> {children} </div>
        </div>
    );

    if (!isOpen) {
        dialog = null;
    }
    
    return ( <div> {dialog} </div>);
};

Modal.propTypes = {
    children: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.node,
    ]),
}

export default Modal;