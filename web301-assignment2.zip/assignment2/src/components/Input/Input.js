import React, {useState} from 'react';
import PropTypes from 'prop-types';

import styles from './Input.module.css';
/*
    CSS modules allow you to reuse class names in different components
    class names are generated after you build the react app
    reduces likelihood of classes clashing
    If you target tags, you won't get the benefits of CSS modules
*/


const Input = (props) => {
    // object destructuring
    const { type } = props;
    const { name } = props;
    const { placeholder } = props;
    const { onChange } = props;

    return (
        <input  type={type} name={name} placeholder={placeholder} onChange={onChange} />
    );
};

Input.propTypes = {
    value: PropTypes.string   
}

export default Input;